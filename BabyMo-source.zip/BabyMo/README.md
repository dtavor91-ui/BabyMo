# BabyMo

Android baby monitor MVP.

- Phone A: baby camera, 720p video + microphone.
- Phone B: monitor, receives live WebRTC video/audio.
- Works over Wi-Fi or cellular when peer-to-peer NAT traversal succeeds.
- Signaling uses a random room topic through ntfy.sh; WebRTC media is encrypted end-to-end with DTLS-SRTP.
- Baby-camera mode includes a black-screen button that lowers display brightness while keeping the app active.

## Build

`gradle assembleDebug`

APK: `app/build/outputs/apk/debug/app-debug.apk`

## Current MVP limitation

No dedicated TURN relay is bundled yet. Some carrier/NAT combinations may fail over cellular. A production release should use a private signaling service and TURN server.
