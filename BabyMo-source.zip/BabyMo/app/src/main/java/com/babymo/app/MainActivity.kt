package com.babymo.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import okhttp3.*
import org.json.JSONObject
import org.webrtc.*
import java.util.UUID
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var panel: LinearLayout
    private lateinit var status: TextView
    private lateinit var roomInput: EditText
    private lateinit var remoteView: SurfaceViewRenderer
    private var engine: CallEngine? = null
    private var darkOverlay: View? = null
    private var role: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        if (!hasPermissions()) requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 10)
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(16,17,20)) }
        remoteView = SurfaceViewRenderer(this).apply { visibility = View.GONE }
        root.addView(remoteView, FrameLayout.LayoutParams(-1, -1))

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(42, 80, 42, 42)
        }
        root.addView(panel, FrameLayout.LayoutParams(-1, -1))

        val title = TextView(this).apply {
            text = "BabyMo"
            textSize = 34f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "טלפון אחד מצלמה • טלפון שני מוניטור"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 34)
        }
        roomInput = EditText(this).apply {
            hint = "קוד חדר (לדוגמה 482731)"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(35,37,43))
            setPadding(24, 18, 24, 18)
            gravity = Gravity.CENTER
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        val gen = Button(this).apply {
            text = "צור קוד חדש"
            setOnClickListener { roomInput.setText((100000..999999).random().toString()) }
        }
        val camera = Button(this).apply {
            text = "הפעל כמצלמת תינוק"
            setOnClickListener { start("camera") }
        }
        val viewer = Button(this).apply {
            text = "הפעל כמוניטור"
            setOnClickListener { start("viewer") }
        }
        status = TextView(this).apply {
            text = "מוכן"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }

        panel.addView(title)
        panel.addView(sub)
        panel.addView(roomInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        panel.addView(gen, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 24 })
        panel.addView(camera, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        panel.addView(viewer, LinearLayout.LayoutParams(-1, -2))
        panel.addView(status)
        setContentView(root)
    }

    private fun hasPermissions() = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun start(which: String) {
        if (!hasPermissions()) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 10)
            status.text = "אשר מצלמה ומיקרופון ואז נסה שוב"
            return
        }
        val room = roomInput.text.toString().trim()
        if (room.length < 4) {
            status.text = "הכנס קוד חדר של לפחות 4 ספרות"
            return
        }
        role = which
        panel.visibility = View.GONE
        remoteView.visibility = if (which == "viewer") View.VISIBLE else View.GONE
        engine = CallEngine(this, room, which, remoteView) { text -> runOnUiThread { showStatus(text) } }
        engine?.start()
        if (which == "camera") showCameraControls(room) else showViewerControls(room)
    }

    private fun showStatus(text: String) {
        status.text = text
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    private fun showCameraControls(room: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 40, 28, 28)
            setBackgroundColor(Color.rgb(16,17,20))
        }
        val info = TextView(this).apply {
            text = "מצלמת תינוק פעילה\nקוד חדר: $room\n720p + אודיו"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val black = Button(this).apply {
            text = "מסך שחור"
            setOnClickListener { enableDarkScreen(room) }
        }
        val stop = Button(this).apply {
            text = "עצור"
            setOnClickListener { recreate() }
        }
        box.addView(info, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = 24 })
        box.addView(black, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = 12 })
        box.addView(stop, LinearLayout.LayoutParams(-1,-2))
        root.addView(box, FrameLayout.LayoutParams(-1,-2,Gravity.TOP))
    }

    private fun showViewerControls(room: String) {
        val badge = TextView(this).apply {
            text = "BabyMo • חדר $room"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(160,0,0,0))
            setPadding(20, 12, 20, 12)
        }
        root.addView(badge, FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = 30 })
    }

    private fun enableDarkScreen(room: String) {
        val lp = window.attributes
        lp.screenBrightness = 0.01f
        window.attributes = lp
        darkOverlay = TextView(this).apply {
            setBackgroundColor(Color.BLACK)
            text = ""
            setOnClickListener {
                val restore = window.attributes
                restore.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                window.attributes = restore
                root.removeView(this)
                darkOverlay = null
            }
        }
        root.addView(darkOverlay, FrameLayout.LayoutParams(-1,-1))
        Toast.makeText(this, "המסך הוחשך. נגיעה תחזיר אותו.", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        engine?.close()
        super.onDestroy()
    }
}

private class CallEngine(
    private val activity: Activity,
    private val room: String,
    private val role: String,
    private val renderer: SurfaceViewRenderer,
    private val onStatus: (String) -> Unit
) {
    private val clientId = UUID.randomUUID().toString()
    private val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
    private val topic = "babymo-${room}"
    private var ws: WebSocket? = null
    private lateinit var egl: EglBase
    private lateinit var factory: PeerConnectionFactory
    private var peer: PeerConnection? = null
    private var capturer: VideoCapturer? = null
    private var videoSource: VideoSource? = null
    private var audioSource: AudioSource? = null
    private var localVideo: VideoTrack? = null
    private var localAudio: AudioTrack? = null
    private val pendingIce = mutableListOf<IceCandidate>()
    private var remoteSdpSet = false

    fun start() {
        egl = EglBase.create()
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(activity.applicationContext).createInitializationOptions()
        )
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext))
            .createPeerConnectionFactory()

        renderer.init(egl.eglBaseContext, null)
        renderer.setMirror(false)
        createPeer()
        if (role == "camera") createLocalMedia()
        connectSignaling()
    }

    private fun createPeer() {
        val servers = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        )
        val config = PeerConnection.RTCConfiguration(servers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }
        peer = factory.createPeerConnection(config, object : PeerConnection.Observer {
            override fun onIceCandidate(c: IceCandidate) {
                send(JSONObject().apply {
                    put("type", "ice")
                    put("sdpMid", c.sdpMid)
                    put("sdpMLineIndex", c.sdpMLineIndex)
                    put("candidate", c.sdp)
                })
            }
            override fun onTrack(transceiver: RtpTransceiver) {
                val track = transceiver.receiver.track()
                if (track is VideoTrack) activity.runOnUiThread { track.addSink(renderer) }
            }
            override fun onConnectionChange(state: PeerConnection.PeerConnectionState) {
                onStatus("חיבור: $state")
            }
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {}
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {}
            override fun onSignalingChange(state: PeerConnection.SignalingState) {}
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) {}
            override fun onAddStream(stream: MediaStream) {}
            override fun onRemoveStream(stream: MediaStream) {}
            override fun onDataChannel(channel: DataChannel) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(receiver: RtpReceiver, mediaStreams: Array<out MediaStream>) {}
            override fun onSelectedCandidatePairChanged(event: CandidatePairChangeEvent) {}
        })
    }

    private fun createLocalMedia() {
        val enumerator = Camera2Enumerator(activity)
        val back = enumerator.deviceNames.firstOrNull { enumerator.isBackFacing(it) }
        val front = enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
        val name = back ?: front ?: throw IllegalStateException("No camera")
        capturer = enumerator.createCapturer(name, null)
        videoSource = factory.createVideoSource(false)
        capturer!!.initialize(SurfaceTextureHelper.create("CaptureThread", egl.eglBaseContext), activity, videoSource!!.capturerObserver)
        capturer!!.startCapture(1280, 720, 20)
        localVideo = factory.createVideoTrack("video", videoSource)
        audioSource = factory.createAudioSource(MediaConstraints())
        localAudio = factory.createAudioTrack("audio", audioSource)
        peer?.addTrack(localVideo, listOf("babymo"))
        peer?.addTrack(localAudio, listOf("babymo"))
    }

    private fun connectSignaling() {
        val req = Request.Builder().url("wss://ntfy.sh/$topic/ws?since=10m").build()
        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                onStatus("מחובר לחדר $room")
                if (role == "viewer") send(JSONObject().put("type", "ready"))
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val envelope = JSONObject(text)
                    if (envelope.optString("event") != "message") return
                    val payload = JSONObject(envelope.optString("message"))
                    if (payload.optString("from") == clientId) return
                    handle(payload)
                } catch (_: Exception) { }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                onStatus("שגיאת איתות: ${t.message}")
            }
        })
    }

    private fun handle(j: JSONObject) {
        when (j.optString("type")) {
            "ready" -> if (role == "camera") makeOffer()
            "offer" -> if (role == "viewer") setRemoteAndAnswer(j.getString("sdp"))
            "answer" -> if (role == "camera") setRemote(SessionDescription.Type.ANSWER, j.getString("sdp"))
            "ice" -> {
                val c = IceCandidate(j.optString("sdpMid"), j.optInt("sdpMLineIndex"), j.optString("candidate"))
                if (remoteSdpSet) peer?.addIceCandidate(c) else pendingIce.add(c)
            }
        }
    }

    private fun makeOffer() {
        peer?.createOffer(object : SdpObserverAdapter() {
            override fun onCreateSuccess(desc: SessionDescription) {
                peer?.setLocalDescription(SdpObserverAdapter(), desc)
                send(JSONObject().put("type", "offer").put("sdp", desc.description))
            }
        }, MediaConstraints())
    }

    private fun setRemoteAndAnswer(sdp: String) {
        peer?.setRemoteDescription(object : SdpObserverAdapter() {
            override fun onSetSuccess() {
                remoteSdpSet = true
                flushIce()
                peer?.createAnswer(object : SdpObserverAdapter() {
                    override fun onCreateSuccess(desc: SessionDescription) {
                        peer?.setLocalDescription(SdpObserverAdapter(), desc)
                        send(JSONObject().put("type", "answer").put("sdp", desc.description))
                    }
                }, MediaConstraints())
            }
        }, SessionDescription(SessionDescription.Type.OFFER, sdp))
    }

    private fun setRemote(type: SessionDescription.Type, sdp: String) {
        peer?.setRemoteDescription(object : SdpObserverAdapter() {
            override fun onSetSuccess() {
                remoteSdpSet = true
                flushIce()
            }
        }, SessionDescription(type, sdp))
    }

    private fun flushIce() {
        pendingIce.forEach { peer?.addIceCandidate(it) }
        pendingIce.clear()
    }

    private fun send(data: JSONObject) {
        data.put("from", clientId)
        val body = JSONObject().put("topic", topic).put("message", data.toString()).toString()
        val req = Request.Builder()
            .url("https://ntfy.sh/")
            .post(RequestBody.create(MediaType.parse("application/json"), body))
            .build()
        http.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: java.io.IOException) { onStatus("שליחה נכשלה") }
            override fun onResponse(call: Call, response: Response) { response.close() }
        })
    }

    fun close() {
        try { capturer?.stopCapture() } catch (_: Exception) {}
        capturer?.dispose(); videoSource?.dispose(); audioSource?.dispose()
        peer?.close(); factory.dispose(); renderer.release(); egl.release(); ws?.close(1000, "bye"); http.dispatcher.executorService.shutdown()
    }
}

private open class SdpObserverAdapter : SdpObserver {
    override fun onCreateSuccess(desc: SessionDescription) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(error: String) {}
    override fun onSetFailure(error: String) {}
}
